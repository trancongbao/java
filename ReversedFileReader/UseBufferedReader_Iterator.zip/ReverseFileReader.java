import java.io.*;
import java.util.Comparator;
import java.util.Iterator;
import java.util.stream.Stream;

//REQ02: The project will be implemented as a single Java class
public class ReverseFileReader {
    private final Stream<String> reversedLineStream;
    private Iterator<String> reversedLineStreamIterator;

    //REQ03a: The constructor for the class will accept one argument that identifies the file to read.
    public ReverseFileReader(String filePath) throws IOException {
        //REQ04: The file to read will be set up by the object constructor when the object is created.
        BufferedReader bufferedReader = new BufferedReader(new FileReader(filePath));
        reversedLineStream = bufferedReader.lines().sorted(Comparator.reverseOrder());
    }

    //REQ03b: The public method will have this signature
    public String readLine() {
        //REQ05: The readLine method will return a single line from the file, not including a newline character on the end.
        //REQ05a: The first call to readLine will return the last line from the file.
        //REQ05b: Each subsequent call to readLine will return the previous line in the file.
        if (reversedLineStreamIterator == null) {
            reversedLineStreamIterator = reversedLineStream.iterator();
        }

        if (reversedLineStreamIterator.hasNext()) {
            return reversedLineStreamIterator.next();
        } else {
            return "";
        }
    }
}
