import java.io.*;

//Question1: is code's simplicity, processing time or memory the priority?
//Question2: is the file local or from a remote location?
//Question3: if one line is read, will the other lines also be read soon after?

//REQ02: The project will be implemented as a single Java class
public class ReverseFileReader {
    private final String filePath;
    private long currentPosition;

    //REQ03a: The constructor for the class will accept one argument that identifies the file to read.
    public ReverseFileReader(String filePath) throws IOException {
        //Question4: what should happen if the file is empty or has only new-line character(s)?
        //REQ04: The file to read will be set up by the object constructor when the object is created.
        this.filePath = filePath;
        currentPosition = new BufferedReader(new FileReader(filePath)).lines().count(); //set at the end of the file
    }

    //REQ03b: The public method will have this signature
    public String readLine() throws IOException {
        //Question5: when all lines have already been read, what should happen?
        // should "" be returned or an exception be thrown?

        //REQ05: The readLine method will return a single line from the file, not including a newline character on the end.
        //REQ05a: The first call to readLine will return the last line from the file.
        //REQ05b: Each subsequent call to readLine will return the previous line in the file.
        if (currentPosition == 0) { //(back) at the start of the file
            return "";
        } else {
            currentPosition--;
            BufferedReader bufferedReader = new BufferedReader(new FileReader(filePath));
            return bufferedReader.lines()
                                 .skip(currentPosition)
                                 .findFirst().orElse("");
        }
    }
}
