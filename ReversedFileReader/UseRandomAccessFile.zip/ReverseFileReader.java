import java.io.IOException;
import java.io.RandomAccessFile;

//REQ02: The project will be implemented as a single Java class
public class ReverseFileReader {
    private final RandomAccessFile randomAccessFile;
    private boolean isStartOfFile;

    //REQ03a: The constructor for the class will accept one argument that identifies the file to read.
    public ReverseFileReader(String filePath) throws IOException {
        //REQ04: The file to read will be set up by the object constructor when the object is created.
        randomAccessFile = new RandomAccessFile(filePath, "r");
        randomAccessFile.seek(randomAccessFile.length());
    }

    //REQ03b: The public method will have this signature
    //REQ05: The readLine method will return a single line from the file, not including a newline character on the end.
    //REQ05a: The first call to readLine will return the last line from the file.
    //REQ05b: Each subsequent call to readLine will return the previous line in the file.
    public String readLine() throws IOException {
        String returnedLine = "";
        if (!isStartOfFile) {
            long endOfLinePtr = randomAccessFile.getFilePointer();
            long offset = 0;
            //calculate the number of bytes in the line (offset)
            while (true) {
                offset++;
                if (offset > endOfLinePtr) { //start of file
                    isStartOfFile = true;
                    break;
                }
                randomAccessFile.seek(endOfLinePtr - offset);
                if (randomAccessFile.readByte() == 10) { // linefeed
                    break;
                }
            }
            byte[] bytes = new byte[(int) offset - 1];
            randomAccessFile.read(bytes);
            if (!isStartOfFile) {
                //move the pointer to end of the previous line, passing '/r'
                randomAccessFile.seek(endOfLinePtr - offset - 1);
            }
            returnedLine = new String(bytes);
        }
        return returnedLine;
    }
}
